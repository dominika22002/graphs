#ifndef VALUE_HH
#define VALUE_HH

#include <vector>
#include <iostream>
#include <math.h>
#include <memory>
// #include <bits/stdc++.h>

using namespace std;

int const VERTICES_SIZE_C = 200;
// int VERTICES_SIZE = VERTICES_SIZE_C;
// float DENSITY = 1;
float EDGES_SIZE_C = VERTICES_SIZE_C*(VERTICES_SIZE_C-1);
int const MAX_VAL = 1000000;
int inf = 100000000;


#endif
